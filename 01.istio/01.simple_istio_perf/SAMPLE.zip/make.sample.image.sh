docker build -t sample SAMPLE
