#!/bin/sh
cd bin
./run.sh
